-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 23, 2022 at 07:53 AM
-- Server version: 5.7.38-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.11

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cabinet_medical_db`
--
CREATE DATABASE IF NOT EXISTS `cabinet_medical_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `cabinet_medical_db`;

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

DROP TABLE IF EXISTS `consultation`;
CREATE TABLE `consultation` (
  `id` int(11) NOT NULL,
  `numConsultation` varchar(15) NOT NULL,
  `idMedecin` int(11) NOT NULL,
  `idPatient` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `dureeConsultation` int(11) NOT NULL,
  `observation` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `consultation`
--

INSERT INTO `consultation` (`id`, `numConsultation`, `idMedecin`, `idPatient`, `date`, `dureeConsultation`, `observation`) VALUES
(1, '2022/00150', 1, 10, '2021-04-02 23:03:07', 25, 'Aucune Observation - Pas de Problème'),
(2, '2022/00002', 1, 10, '2021-05-10 10:00:00', 10, 'Très grave ... ggggg'),
(3, '2022/18508', 1, 10, '2022-05-21 15:23:25', 20, 'Aucune  gggg');

-- --------------------------------------------------------

--
-- Table structure for table `ligne_ordonnance`
--

DROP TABLE IF EXISTS `ligne_ordonnance`;
CREATE TABLE `ligne_ordonnance` (
  `id` int(11) NOT NULL,
  `idConsultation` int(11) NOT NULL,
  `medicament` varchar(40) NOT NULL,
  `qte` int(11) NOT NULL,
  `nbre_prise_jour` int(11) NOT NULL,
  `nb_jours` int(11) NOT NULL,
  `observation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ligne_ordonnance`
--

INSERT INTO `ligne_ordonnance` (`id`, `idConsultation`, `medicament`, `qte`, `nbre_prise_jour`, `nb_jours`, `observation`) VALUES
(2, 3, 'Malox', 1, 5, 5, 'Après Repat ..'),
(4, 3, 'Doliplrane', 2, 10, 10, 'Chaque 6 heures'),
(5, 3, 'Siro-Gel', 3, 4, 4, 'en cas de fièvre');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `nom` varchar(45) CHARACTER SET latin1 NOT NULL,
  `prenom` varchar(45) CHARACTER SET latin1 NOT NULL,
  `adresse` varchar(45) CHARACTER SET latin1 NOT NULL,
  `age` int(11) NOT NULL,
  `gs` enum('A+','A-','B+','B-','AB+','AB-','O+','O-') CHARACTER SET latin1 NOT NULL,
  `tel` varchar(20) CHARACTER SET latin1 NOT NULL,
  `taill` int(11) NOT NULL,
  `poids` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `nom`, `prenom`, `adresse`, `age`, `gs`, `tel`, `taill`, `poids`) VALUES
(10, 'BRIHMAT', 'RACHID', 'el eulma', 25, 'A-', '0896-86-86-86', 180, 82),
(12, 'SAMIR', 'Younes', 'el eulma', 25, 'AB+', '0896-86-86-86', 180, 63),
(15, 'Hedjazi', 'Djalal', 'el eulma', 25, 'O-', '0896-86-86-86', 180, 62),
(16, 'Omar', 'Omar', 'Bejaia', 30, 'A-', '078955244', 200, 95),
(17, 'Omar333', 'Omar', 'Bejaia', 30, 'A-', '0789-55-24-4 ', 200, 95);

-- --------------------------------------------------------

--
-- Table structure for table `rendez_vous`
--

DROP TABLE IF EXISTS `rendez_vous`;
CREATE TABLE `rendez_vous` (
  `id` int(11) NOT NULL,
  `datePR` datetime NOT NULL,
  `dateRD` datetime NOT NULL,
  `observation` varchar(500) DEFAULT NULL,
  `idPatient` int(11) NOT NULL,
  `idSecretaire` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rendez_vous`
--

INSERT INTO `rendez_vous` (`id`, `datePR`, `dateRD`, `observation`, `idPatient`, `idSecretaire`) VALUES
(1, '2022-05-25 21:12:31', '2022-05-17 21:12:31', 'ok', 10, 1),
(2, '2022-05-22 10:12:44', '2023-05-22 10:12:44', 'ok', 16, 1),
(3, '2022-05-01 21:13:44', '2022-05-25 21:13:44', 'ok', 15, 1),
(8, '2022-05-22 00:00:00', '2022-05-26 00:00:00', 'null', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) CHARACTER SET latin1 NOT NULL,
  `prenom` varchar(30) CHARACTER SET latin1 NOT NULL,
  `username` varchar(45) CHARACTER SET latin1 NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 NOT NULL,
  `role` enum('Medecin','Secrétaire') CHARACTER SET latin1 NOT NULL DEFAULT 'Secrétaire'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nom`, `prenom`, `username`, `password`, `role`) VALUES
(1, 'Rayane', 'Rayane', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Medecin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idMedecin` (`idMedecin`),
  ADD KEY `idPatient` (`idPatient`);

--
-- Indexes for table `ligne_ordonnance`
--
ALTER TABLE `ligne_ordonnance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idConsultation` (`idConsultation`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rendez_vous`
--
ALTER TABLE `rendez_vous`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idPatient` (`idPatient`),
  ADD KEY `idSecretaire` (`idSecretaire`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ligne_ordonnance`
--
ALTER TABLE `ligne_ordonnance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `rendez_vous`
--
ALTER TABLE `rendez_vous`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `consultation_ibfk_1` FOREIGN KEY (`idMedecin`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `consultation_ibfk_2` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`id`);

--
-- Constraints for table `ligne_ordonnance`
--
ALTER TABLE `ligne_ordonnance`
  ADD CONSTRAINT `ligne_ordonnance_ibfk_1` FOREIGN KEY (`idConsultation`) REFERENCES `consultation` (`id`);

--
-- Constraints for table `rendez_vous`
--
ALTER TABLE `rendez_vous`
  ADD CONSTRAINT `rendez_vous_ibfk_1` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`id`),
  ADD CONSTRAINT `rendez_vous_ibfk_2` FOREIGN KEY (`idSecretaire`) REFERENCES `user` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
