/*
 * JTattoo CustomIconFactorySample (c) 2016 by MH Software-Entwicklung
 *
 * This sample shows how to customize the icons used in JTattoo
 */


package com.jtattoo.samples;

import com.jtattoo.plaf.AbstractIconFactory;
import com.jtattoo.plaf.mcwin.McWinIcons;
import com.jtattoo.plaf.mcwin.McWinLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.Icon;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 *
 * @author Michael Hagen
 */
public class CustomIconFactorySample extends BaseSampleFrame {
    
    public CustomIconFactorySample() {
        super("CustomIconFactorySample");
        JScrollPane treeScrollPane = new JScrollPane(new JTree());
        treeScrollPane.setMinimumSize(new Dimension(120, 80));
        JScrollPane textAreaScrollPane = new JScrollPane(new JTextArea("Hello World"));
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, treeScrollPane, textAreaScrollPane);
        splitPane.setDividerLocation(140);
        splitPane.setOneTouchExpandable(true);
        contentPanel.add(splitPane, BorderLayout.CENTER);
    }

//------------------------------------------------------------------------------    
    public static void main(String[] args) {
//------------------------------------------------------------------------------    
        try {
            
            // Select the Look and Feel
            UIManager.setLookAndFeel(new CustomLookAndFeel());

            SwingUtilities.invokeLater(new Runnable() {

                @Override
                public void run() {
                    // Start the application
                    final CustomIconFactorySample app = new CustomIconFactorySample();
                    app.setSize(600, 400);
                    app.setLocationRelativeTo(null);
                    app.setVisible(true);
                }
            });
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    } // end main

//------------------------------------------------------------------------------    
// inner classes    
//------------------------------------------------------------------------------    
    public static class CustomLookAndFeel extends McWinLookAndFeel {
        
        @Override
        public AbstractIconFactory getIconFactory() {
            return CustomIconFactory.getInstance();
        }
        
    } // end of class CustomLookAndFeel
    
//------------------------------------------------------------------------------    
    public static class CustomIconFactory implements AbstractIconFactory {

        private static CustomIconFactory instance = null;

        private CustomIconFactory() {
        }

        public static synchronized CustomIconFactory getInstance() {
            if (instance == null) {
                instance = new CustomIconFactory();
            }
            return instance;
        }
        
        @Override
        public Icon getOptionPaneErrorIcon() {
            return McWinIcons.getOptionPaneErrorIcon();
        }

        @Override
        public Icon getOptionPaneWarningIcon() {
            return McWinIcons.getOptionPaneWarningIcon();
        }

        @Override
        public Icon getOptionPaneInformationIcon() {
            return McWinIcons.getOptionPaneInformationIcon();
        }

        @Override
        public Icon getOptionPaneQuestionIcon() {
            return McWinIcons.getOptionPaneQuestionIcon();
        }

        @Override
        public Icon getFileChooserUpFolderIcon() {
            return McWinIcons.getFileChooserUpFolderIcon();
        }

        @Override
        public Icon getFileChooserHomeFolderIcon() {
            return McWinIcons.getFileChooserHomeFolderIcon();
        }

        @Override
        public Icon getFileChooserNewFolderIcon() {
            return McWinIcons.getFileChooserNewFolderIcon();
        }

        @Override
        public Icon getFileChooserDetailViewIcon() {
            return McWinIcons.getFileChooserDetailViewIcon();
        }

        @Override
        public Icon getFileChooserListViewIcon() {
            return McWinIcons.getFileChooserListViewIcon();
        }

        @Override
        public Icon getFileViewComputerIcon() {
            return McWinIcons.getFileViewComputerIcon();
        }

        @Override
        public Icon getFileViewFloppyDriveIcon() {
            return McWinIcons.getFileViewFloppyDriveIcon();
        }

        @Override
        public Icon getFileViewHardDriveIcon() {
            return McWinIcons.getFileViewHardDriveIcon();
        }

        @Override
        public Icon getMenuIcon() {
            return McWinIcons.getMenuIcon();
        }

        @Override
        public Icon getIconIcon() {
            return McWinIcons.getIconIcon();
        }

        @Override
        public Icon getMaxIcon() {
            return McWinIcons.getMaxIcon();
        }

        @Override
        public Icon getMinIcon() {
            return McWinIcons.getMinIcon();
        }

        @Override
        public Icon getCloseIcon() {
            return McWinIcons.getCloseIcon();
        }

        @Override
        public Icon getPaletteCloseIcon() {
            return McWinIcons.getPaletteCloseIcon();
        }

        @Override
        public Icon getRadioButtonIcon() {
            return McWinIcons.getRadioButtonIcon();
        }

        @Override
        public Icon getCheckBoxIcon() {
            return McWinIcons.getCheckBoxIcon();
        }

        @Override
        public Icon getComboBoxIcon() {
            return McWinIcons.getComboBoxIcon();
        }

        @Override
        public Icon getTreeOpenIcon() {
            return McWinIcons.getTreeOpenedIcon();
        }

        @Override
        public Icon getTreeCloseIcon() {
            return McWinIcons.getTreeClosedIcon();
        }

        @Override
        public Icon getTreeLeafIcon() {
            return McWinIcons.getTreeLeafIcon();
        }

        @Override
        public Icon getTreeCollapsedIcon() {
            return McWinIcons.getTreeCollapsedIcon();
        }

        @Override
        public Icon getTreeExpandedIcon() {
            return McWinIcons.getTreeExpandedIcon();
        }

        @Override
        public Icon getMenuArrowIcon() {
            return McWinIcons.getMenuArrowIcon();
        }

        @Override
        public Icon getMenuCheckBoxIcon() {
            return McWinIcons.getMenuCheckBoxIcon();
        }

        @Override
        public Icon getMenuRadioButtonIcon() {
            return McWinIcons.getMenuRadioButtonIcon();
        }

        @Override
        public Icon getUpArrowIcon() {
            return McWinIcons.getUpArrowIcon();
        }

        @Override
        public Icon getDownArrowIcon() {
            return McWinIcons.getDownArrowIcon();
        }

        @Override
        public Icon getLeftArrowIcon() {
            return McWinIcons.getLeftArrowIcon();
        }

        @Override
        public Icon getRightArrowIcon() {
            return McWinIcons.getRightArrowIcon();
        }

        @Override
        public Icon getSplitterUpArrowIcon() {
            //return McWinIcons.getSplitterUpArrowIcon();
            return McWinIcons.getUpArrowIcon();
        }

        @Override
        public Icon getSplitterDownArrowIcon() {
            //return McWinIcons.getSplitterDownArrowIcon();
            return McWinIcons.getDownArrowIcon();
        }

        @Override
        public Icon getSplitterLeftArrowIcon() {
            //return McWinIcons.getSplitterLeftArrowIcon();
            return McWinIcons.getLeftArrowIcon();
        }

        @Override
        public Icon getSplitterRightArrowIcon() {
            //return McWinIcons.getSplitterRightArrowIcon();
            return McWinIcons.getRightArrowIcon();
        }

        @Override
        public Icon getSplitterHorBumpIcon() {
            return McWinIcons.getSplitterHorBumpIcon();
        }

        @Override
        public Icon getSplitterVerBumpIcon() {
            return McWinIcons.getSplitterVerBumpIcon();
        }

        @Override
        public Icon getThumbHorIcon() {
            return McWinIcons.getThumbHorIcon();
        }

        @Override
        public Icon getThumbVerIcon() {
            return McWinIcons.getThumbVerIcon();
        }

        @Override
        public Icon getThumbHorIconRollover() {
            return McWinIcons.getThumbHorIconRollover();
        }

        @Override
        public Icon getThumbVerIconRollover() {
            return McWinIcons.getThumbVerIconRollover();
        }
        
    } // end of class CustomIconFactory
   
} // end of class CustomIconFactorySample
